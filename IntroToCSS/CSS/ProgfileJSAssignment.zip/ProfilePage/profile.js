console.log("Connected to JS");


function change() {
    var name = document.querySelector("#name");
    name.innerText = 'Chuck Norris';

}

function remove() {
    var remove = document.querySelector(".rmv")
    remove.remove();
}
