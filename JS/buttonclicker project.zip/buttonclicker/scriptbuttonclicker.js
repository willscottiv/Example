console.log("Connected to JS");

function changeText(change) {
    change.innerText = "Logout";
}

function remove(rmv) {
    rmv.remove();
}

function liked() {
    alert("Ninja was liked");
}
