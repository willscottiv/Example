console.log("Connected to JS");


function al() {
    alert("You did it!")
}


function remove() {
    var remove = document.querySelector(".bottom-main")
    remove.remove();
}


function convert(change) {
    // alert("Loading weather report")

    var degree = change.value;
    var temp = document.querySelector("#1a");

    if (degree === "fahrenheit") {
        temp.innerText = "75&#176;"
    }

}
